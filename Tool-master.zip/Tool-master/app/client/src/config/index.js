//process.env.NODE_ENV = 'development';

import config from './env/development';

config.someEnvAgnosticSetting = true;

// export config
export default config; 