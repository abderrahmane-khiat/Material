const config = {
  "apiEndpoint": "http://localhost:5000/"
}

export default config